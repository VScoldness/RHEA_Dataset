import pandas as pd

lc = "latticeConstant/latticeConstat_300.xlsx"
df = pd.read_excel(lc, index_col=[0])